let count = 0; // variable name count

function increaseBtn() {
    document.getElementById('counterNumber').innerHTML = ++count;
    }

function decreaseBtn() { 
    document.getElementById('counterNumber').innerHTML = --count;
    }
